# ADR 0018 — Propagate Runtime Control denials through Governance without a second control plane

Status: Accepted  
Date: 2026-08-08

## Context

P1.6a made Verifiable AI Governance the durable administrative authority for runtime kill-switch
state and revocation floors. P1.6b made policy-model-router enforce the projected Runtime Control
state before replay consumption.

`decisao-agent` already requests model routing through Governance. It intentionally does not receive
or verify the signed Runtime Authorization and does not call policy-model-router directly. Its LLM
narrative is optional and cannot alter the deterministic credit decision.

The remaining integration question is how Runtime Control denials should reach the Credit Desk
without introducing another control plane or teaching the business service to consume Redis.

## Decision

The Credit Desk continues to trust only the durable Governance routing-decision API.

It does **not**:

- read or write the Runtime Control Redis projection;
- activate or deactivate kill switches;
- receive, forward, or verify Runtime Authorization artifacts;
- call policy-model-router directly;
- reinterpret a Runtime Violation as a credit decision.

Governance remains responsible for translating both local Runtime Control enforcement and trusted
Router violations into one durable routing outcome. `decisao-agent` preserves the returned
machine-readable `reason_code` in `ModelRoutingDeniedError` and records that bounded structural code
on the client span.

The stable P1.6 Runtime Control reasons are:

- `kill_switch_engaged` — runtime is administratively disabled;
- `runtime_authorization_revoked` — a previously issued authorization is at or below the retained
  revocation floor;
- `runtime_control_unavailable` — Runtime Control state cannot be trusted and Governance fails
  closed as a dependency-unavailable outcome.

## Credit decision semantics

A Runtime Control denial affects only the optional LLM narrative path. `ModelRoutingDeniedError`
remains a subtype of `ModelRoutingUnavailableError`, which is already handled as best effort by the
narrative drafting path.

Therefore:

1. deterministic credit evaluation runs first;
2. governed routing may be denied by Runtime Control;
3. no chat completion is attempted after that denial;
4. `CreditOpinion.narrative` remains `None`;
5. deterministic decision, score, authority, reason codes, and blocking reasons remain unchanged.

This is intentional fail-closed behavior for AI assistance without making the probabilistic layer an
authority over the deterministic credit core.

## Evidence and observability

The Governance routing-decision ID remains the durable functional correlation identifier. Router
violations are validated and persisted by Governance before the Credit Desk receives the blocked
outcome.

The W3C trace remains operational telemetry only. The Credit Desk span may include the bounded
machine-readable denial `reason_code`; it must not include Runtime Authorization material, Redis
snapshots, prompts, model outputs, customer data, credentials, or the Runtime Violation payload.

## Consequences

- Emergency runtime controls propagate to the downstream workload without an alternate write path.
- Old authorizations remain unusable after restore because revocation is enforced upstream by the
  Router, not reconstructed by the Credit Desk.
- The deterministic credit result remains available when the optional LLM narrative is disabled.
- Redis and cryptographic authorization details remain outside the Credit Desk trust boundary.
