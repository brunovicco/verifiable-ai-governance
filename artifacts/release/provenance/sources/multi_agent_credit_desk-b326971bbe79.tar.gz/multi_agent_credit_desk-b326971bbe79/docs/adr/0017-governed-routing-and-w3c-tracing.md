# ADR 0017 — Govern model routing through the control plane and propagate W3C traces

Status: Accepted  
Date: 2026-08-07

## Context

`decisao-agent` previously called `policy-model-router` directly. After P1.3
and P1.4 that path bypasses the control plane responsible for:

- reading the approved agent/model registry scope;
- issuing the signed runtime authorization;
- persisting the routing attempt;
- validating Router violation evidence;
- maintaining the hash-chained audit record.

The repository already pins `a2a-otel-kit` 0.4.2 and its identifier model
explicitly separates technical trace IDs from functional audit identifiers.

## Decision

`decisao-agent` will request model routing from Verifiable AI Governance:

```text
decisao-agent
  -> Governance /agents/{agent_id}/routing-decisions
     -> signed runtime authorization
     -> policy-model-router /route
     -> durable allowed/blocked decision
  -> optional LLM narrative only after ALLOWED
```

The Credit Desk does not receive, store, forward, or verify the signed runtime
authorization itself. Governance owns that trust boundary.

The client propagates only W3C `traceparent`/`tracestate`. Governance's routing
decision ID returned by the API becomes the `RoutingDecisionId` used by the
Credit Desk and is also the durable correlation ID committed to P1.4 evidence.

Inbound A2A requests are wrapped with `a2a-otel-kit`'s
`TracingRequestHandler`, so the same trace can continue through Credit Desk,
Governance and the Router.

## Failure semantics

Routing remains fail-closed for the optional LLM narrative:

- Governance `allowed` -> model group may be used;
- Governance `blocked` -> `ModelRoutingDeniedError`;
- unavailable/malformed/mismatched response -> `ModelRoutingUnavailableError`.

Both errors remain under `ModelRoutingUnavailableError`, so an LLM routing
failure still cannot alter the deterministic credit decision.

No automatic kill switch is introduced here; that remains P1.6.
