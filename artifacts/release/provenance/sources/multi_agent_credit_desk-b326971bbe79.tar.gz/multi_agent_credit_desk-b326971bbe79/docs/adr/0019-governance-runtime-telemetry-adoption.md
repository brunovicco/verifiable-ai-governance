# ADR 0019 — Emit sanitized Credit Desk runtime telemetry through a2a-otel-kit

Status: Accepted  
Date: 2026-08-09

## Context

P1.7a added a closed, normalized runtime-telemetry ingestion boundary to Verifiable AI Governance.
P1.7b added an explicit `GovernanceRuntimeTelemetrySink` to `a2a-otel-kit` and published that
capability in `a2a-otel-kit` 0.5.0.

The Credit Desk already uses `a2a-otel-kit` for W3C tracing, but its operational structured events
are not yet persisted as Governance evidence.

The integration must not introduce a second HTTP client, duplicate the Governance telemetry
contract, expose credit application content, or make optional evidence delivery authoritative over
the deterministic credit decision.

## Decision

`decisao-agent` adopts the published `GovernanceRuntimeTelemetrySink` through a consumer-owned
`RuntimeTelemetryPort`.

The A2A executor emits only terminal credit-evaluation lifecycle events:

- `decisao_agent.evaluation.completed`;
- `decisao_agent.evaluation.failed`.

The event attributes are restricted to:

- `component=a2a_executor`;
- `operation=credit_evaluation`;
- A2A `context_id` as `correlation_id`;
- A2A `task_id` as `request_id`;
- elapsed `duration_ms`;
- exception class name as `error.type` for failures.

No snapshot fields, customer identifiers, monetary values, deterministic opinion fields, prompts,
messages, model output, narrative, authorization material, header values, or exception messages are
added to runtime telemetry.

## Configuration

Adoption is explicit and disabled by default:

```env
DECISAO_AGENT_GOVERNANCE_TELEMETRY_ENABLED=false
DECISAO_AGENT_GOVERNANCE_TELEMETRY_API_KEY=
```

The telemetry sink deliberately reuses the existing governed runtime binding:

```env
DECISAO_AGENT_GOVERNANCE_BASE_URL=
DECISAO_AGENT_GOVERNANCE_AGENT_ID=
```

The telemetry API key is resolved through a credential provider and is never copied into
representable settings.

## Failure semantics

Telemetry delivery is fail-open for the Credit Desk business workflow.

A sink failure:

1. does not change a completed/failed A2A task state;
2. does not alter the deterministic credit opinion;
3. does not trigger a second telemetry event;
4. logs only the exception class name, never exception text or response content.

Invalid non-secret configuration while telemetry is explicitly enabled fails during application
construction instead of creating a partially configured sink.

## Trace semantics

`GovernanceRuntimeTelemetrySink` captures the active W3C trace/span identifiers when preparing the
event. `correlation_id` and `request_id` remain business/runtime identifiers and are not replaced by
trace identifiers.

## Consequences

- Governance can persist normalized operational evidence emitted by the Credit Desk.
- The Credit Desk does not know the Governance HTTP payload schema.
- The deterministic decision remains independent from telemetry availability.
- Sensitive business content stays outside the telemetry boundary.
- P1.7d can validate the real Credit Desk -> Governance ingestion and audit chain without adding
  another producer implementation.
