# Governed runtime integration

Configure `decisao-agent` to call Governance instead of the Router directly.

```env
DECISAO_AGENT_GOVERNANCE_BASE_URL=http://governance-api:8000
DECISAO_AGENT_GOVERNANCE_AGENT_ID=<id returned by the canonical demo seed>

# Production:
DECISAO_AGENT_GOVERNANCE_BEARER_TOKEN=<workload identity token>

# Local/demo alternative only:
DECISAO_AGENT_GOVERNANCE_DEV_USER_ID=demo.requester

DECISAO_AGENT_GOVERNANCE_TIMEOUT_SECONDS=5
DECISAO_AGENT_GOVERNANCE_MAX_RESPONSE_BYTES=262144
```

Enable OpenTelemetry using the existing `a2a-otel-kit` environment contract:

```env
A2A_OTEL_ENABLED=true
A2A_OTEL_OTLP_ENDPOINT=http://otel-collector:4318/v1/traces
A2A_OTEL_OTLP_TIMEOUT_SECONDS=5
DECISAO_AGENT_ENV=demo
```

The client never forwards the A2A request body, arbitrary headers, API keys or
customer content to telemetry. Only W3C `traceparent`/`tracestate` are
propagated.

The Governance routing-decision ID is the durable audit correlation identifier;
the trace ID remains operational telemetry.

## P1.6 Runtime Control propagation

Runtime Control remains owned by Verifiable AI Governance. `decisao-agent` does not read or write
the Redis projection and never calls the Router directly.

The effective path is:

```text
Credit Desk
  -> Governance routing decision
     -> Governance Runtime Control pre-check
     -> signed Runtime Authorization
     -> policy-model-router Runtime Control enforcement
     -> trusted RuntimeViolation on denial
     -> Governance durable routing evidence
  -> optional narrative only after ALLOWED
```

Stable Runtime Control outcomes reaching the integration boundary are:

- `kill_switch_engaged`: the optional model invocation is blocked;
- `runtime_authorization_revoked`: a pre-kill authorization remains invalid after restore;
- `runtime_control_unavailable`: Governance returns dependency-unavailable and fails closed.

For `kill_switch_engaged` and `runtime_authorization_revoked`, the Governance routing-decision ID and
machine-readable reason are preserved by `ModelRoutingDeniedError`. The reason code may be attached
to the W3C client span as bounded structural telemetry; the Runtime Violation payload itself is not
copied into Credit Desk telemetry.

The deterministic credit evaluation is not changed by any of these outcomes. Runtime Control can
suppress the optional LLM narrative, but it cannot change the deterministic decision, score,
approval authority, reason codes, or blocking reasons. Chat completion is never attempted after a
governed routing denial.

After kill-switch deactivation, only a newly issued authorization above Governance's retained
`revoked_through_agent_version` floor can reach the Router successfully. The Credit Desk does not
reconstruct or second-guess that revocation logic.

## P1.7 sanitized runtime telemetry

`decisao-agent` can persist terminal operational evidence in Governance through the published
`a2a-otel-kit` 0.5.0 sink.

The feature is opt-in:

```env
DECISAO_AGENT_GOVERNANCE_TELEMETRY_ENABLED=true
DECISAO_AGENT_GOVERNANCE_TELEMETRY_API_KEY=<agent-scoped telemetry key>
```

The sink reuses `DECISAO_AGENT_GOVERNANCE_BASE_URL` and
`DECISAO_AGENT_GOVERNANCE_AGENT_ID`; there is no second Governance endpoint or Agent binding.

Only terminal `completed` / `failed` evaluation events are emitted. The payload contains structural
metadata (`context_id`, `task_id`, duration, operation, component and exception class name) plus
active W3C trace/span identifiers captured by `a2a-otel-kit`.

Credit application data, deterministic opinion fields, prompts, narrative text, authorization
material, header values, response bodies and exception messages are excluded.

Delivery is fail-open for the deterministic Credit Desk workflow and a delivery failure is not
recursively emitted as telemetry.
