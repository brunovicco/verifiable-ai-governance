"""Governance-mediated model routing with W3C trace propagation."""

import json
import os
from contextlib import nullcontext
from datetime import datetime
from decimal import Decimal
from typing import Annotated, Literal

import httpx
from a2a_otel_kit import Observability, inject_trace_context
from opentelemetry.trace import SpanKind
from pydantic import BaseModel, ConfigDict, StringConstraints, ValidationError

from credit_desk_contracts.enums import ModelGroup
from credit_desk_contracts.identifiers import RoutingDecisionId, TaskId, WorkflowId
from credit_desk_contracts.routing import (
    ModelRouteDecision,
    ModelRouteRequest,
    RejectedCandidate,
)
from decisao_agent.application.ports import ModelRoutingPort
from decisao_agent.domain.errors import (
    ModelRoutingDeniedError,
    ModelRoutingUnavailableError,
)

_BASE_URL_ENV = "DECISAO_AGENT_GOVERNANCE_BASE_URL"
_AGENT_ID_ENV = "DECISAO_AGENT_GOVERNANCE_AGENT_ID"
_BEARER_TOKEN_ENV = "DECISAO_AGENT_GOVERNANCE_BEARER_TOKEN"  # noqa: S105
_DEV_USER_ID_ENV = "DECISAO_AGENT_GOVERNANCE_DEV_USER_ID"
_TIMEOUT_ENV = "DECISAO_AGENT_GOVERNANCE_TIMEOUT_SECONDS"
_MAX_RESPONSE_BYTES_ENV = "DECISAO_AGENT_GOVERNANCE_MAX_RESPONSE_BYTES"

_DEFAULT_BASE_URL = "http://localhost:8000"
_DEFAULT_TIMEOUT_SECONDS = 5.0
_DEFAULT_MAX_RESPONSE_BYTES = 262_144

_Identifier = Annotated[str, StringConstraints(min_length=1, max_length=200)]
_Description = Annotated[str, StringConstraints(min_length=1, max_length=2000)]
_Digest = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{64}$")]


class _StrictResponse(BaseModel):
    """Closed subset of the Governance transport contract used by decisao-agent."""

    model_config = ConfigDict(extra="forbid", frozen=True)


class _GovernanceRejectedCandidate(_StrictResponse):
    model_group: _Identifier
    reason: _Description
    reason_code: _Identifier
    observed_value: str
    required_value: str


class _GovernanceDecision(_StrictResponse):
    """Exact P1.4 Governance routing-decision response shape."""

    id: _Identifier
    ai_system_id: _Identifier
    initiative_id: _Identifier
    agent_id: _Identifier
    requested_by: _Identifier
    requested_at: datetime
    scope_digest: _Digest
    workflow_id: _Identifier
    task_id: _Identifier
    workload: _Identifier
    risk_level: _Identifier
    data_classification: _Identifier
    context_tokens_estimated: int
    max_output_tokens_estimated: int
    structured_output_required: bool
    max_latency_ms: int
    max_cost_usd: Decimal
    outcome: Literal["pending", "allowed", "blocked", "dependency_unavailable"]
    decision_source: str | None
    router_decision_id: str | None
    router_outcome: str | None
    decided_at: datetime | None
    selected_model_group: str | None
    rejected_model_group: str | None
    reason: str | None
    reason_code: str | None
    observed_value: str | None
    required_value: str | None
    rejected_candidates: list[_GovernanceRejectedCandidate]
    policy_id: str | None
    policy_version: str | None
    policy_digest: str | None
    service_version: str | None
    environment: str | None
    runtime_violation: dict[str, object] | None
    version: int
    created_at: datetime
    updated_at: datetime


class ModelRouterClient(ModelRoutingPort):
    """Request model routing through Governance rather than bypassing its control plane."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        agent_id: str | None = None,
        bearer_token: str | None = None,
        dev_user_id: str | None = None,
        timeout_seconds: float | None = None,
        max_response_bytes: int | None = None,
        observability: Observability | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        """Initialize the bounded Governance routing client."""
        self._base_url = (base_url or os.environ.get(_BASE_URL_ENV, _DEFAULT_BASE_URL)).rstrip("/")
        self._agent_id = agent_id or os.environ.get(_AGENT_ID_ENV)
        self._bearer_token = bearer_token or os.environ.get(_BEARER_TOKEN_ENV)
        self._dev_user_id = dev_user_id or os.environ.get(_DEV_USER_ID_ENV)
        configured_timeout = timeout_seconds
        if configured_timeout is None:
            configured_timeout = float(os.environ.get(_TIMEOUT_ENV, str(_DEFAULT_TIMEOUT_SECONDS)))
        configured_max_bytes = max_response_bytes
        if configured_max_bytes is None:
            configured_max_bytes = int(
                os.environ.get(
                    _MAX_RESPONSE_BYTES_ENV,
                    str(_DEFAULT_MAX_RESPONSE_BYTES),
                )
            )
        self._timeout = httpx.Timeout(configured_timeout)
        self._max_response_bytes = configured_max_bytes
        self._observability = observability
        self._transport = transport

    async def route(self, request: ModelRouteRequest) -> ModelRouteDecision:
        """Obtain one governed routing decision without retrying the non-idempotent POST."""
        if not self._agent_id:
            raise ModelRoutingUnavailableError("Governance agent id is not configured")
        headers = self._request_headers()
        span_context = (
            self._observability.start_span(
                "decisao_agent.governance.route",
                kind=SpanKind.CLIENT,
                attributes={
                    "component": "verifiable-ai-governance",
                    "operation": "runtime.route",
                },
                record_exception=False,
            )
            if self._observability is not None
            else nullcontext()
        )

        with span_context as span:
            inject_trace_context(headers)
            try:
                async with (
                    httpx.AsyncClient(
                        timeout=self._timeout,
                        transport=self._transport,
                    ) as client,
                    client.stream(
                        "POST",
                        (f"{self._base_url}/api/v1/agents/{self._agent_id}/routing-decisions"),
                        headers=headers,
                        json=_governance_request_payload(request),
                    ) as response,
                ):
                    body = await self._read_bounded(response)
                    status_code = response.status_code
            except httpx.HTTPError as exc:
                if span is not None:
                    span.set_attribute("outcome", "error")
                    span.set_attribute("error.type", type(exc).__name__)
                raise ModelRoutingUnavailableError("Governance routing request failed") from exc

            decision = _parse_governance_decision(body)
            _require_request_binding(request, decision)
            if span is not None:
                span.set_attribute("correlation_id", decision.id)
                span.set_attribute("http.status_code", status_code)

            if status_code == 200 and decision.outcome == "allowed":
                if span is not None:
                    span.set_attribute("outcome", "success")
                return _to_credit_decision(decision)

            if status_code == 422 and decision.outcome == "blocked":
                reason_code = decision.reason_code or "governance_blocked"
                if span is not None:
                    span.set_attribute("outcome", "rejected")
                    span.set_attribute("reason_code", reason_code)
                raise ModelRoutingDeniedError(
                    routing_decision_id=decision.id,
                    reason_code=reason_code,
                )

            if span is not None:
                span.set_attribute("outcome", "error")
            if status_code == 503 and decision.outcome == "dependency_unavailable":
                raise ModelRoutingUnavailableError("Governance routing dependency is unavailable")
            raise ModelRoutingUnavailableError(
                "Governance routing response status and outcome do not match"
            )

    def _request_headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self._bearer_token:
            headers["Authorization"] = f"Bearer {self._bearer_token}"
            return headers
        if self._dev_user_id:
            headers["X-User-Id"] = self._dev_user_id
            return headers
        raise ModelRoutingUnavailableError("Governance authentication is not configured")

    async def _read_bounded(self, response: httpx.Response) -> bytes:
        content_length = response.headers.get("content-length")
        if content_length is not None:
            try:
                if int(content_length) > self._max_response_bytes:
                    raise ModelRoutingUnavailableError("Governance routing response is too large")
            except ValueError as exc:
                raise ModelRoutingUnavailableError(
                    "Governance routing Content-Length is invalid"
                ) from exc

        chunks: list[bytes] = []
        received = 0
        async for chunk in response.aiter_bytes():
            received += len(chunk)
            if received > self._max_response_bytes:
                raise ModelRoutingUnavailableError("Governance routing response is too large")
            chunks.append(chunk)
        return b"".join(chunks)


def _governance_request_payload(request: ModelRouteRequest) -> dict[str, object]:
    return {
        "workflow_id": str(request.workflow_id),
        "task_id": str(request.task_id),
        "workload": request.workload.value,
        "context_tokens_estimated": request.context_tokens_estimated,
        "max_output_tokens_estimated": request.max_output_tokens_estimated,
        "structured_output_required": request.structured_output_required,
        "max_latency_ms": request.max_latency_ms,
        "max_cost_usd": str(request.max_cost_usd),
    }


def _parse_governance_decision(body: bytes) -> _GovernanceDecision:
    try:
        payload = json.loads(body)
        return _GovernanceDecision.model_validate(payload)
    except (
        UnicodeDecodeError,
        json.JSONDecodeError,
        ValidationError,
        TypeError,
    ) as exc:
        raise ModelRoutingUnavailableError("Governance routing response is invalid") from exc


def _require_request_binding(
    request: ModelRouteRequest,
    decision: _GovernanceDecision,
) -> None:
    if (
        decision.workflow_id != str(request.workflow_id)
        or decision.task_id != str(request.task_id)
        or decision.workload != request.workload.value
    ):
        raise ModelRoutingUnavailableError("Governance routing decision does not match the request")


def _to_credit_decision(decision: _GovernanceDecision) -> ModelRouteDecision:
    if decision.selected_model_group is None or decision.decided_at is None:
        raise ModelRoutingUnavailableError("Allowed Governance decision is incomplete")
    try:
        selected = ModelGroup(decision.selected_model_group)
        rejected = tuple(
            RejectedCandidate(
                model_group=ModelGroup(candidate.model_group),
                reason=candidate.reason,
            )
            for candidate in decision.rejected_candidates
        )
    except ValueError as exc:
        raise ModelRoutingUnavailableError(
            "Governance selected an unsupported model group"
        ) from exc

    return ModelRouteDecision(
        schema_version="1.0",
        routing_decision_id=RoutingDecisionId(decision.id),
        decided_at=decision.decided_at,
        workflow_id=WorkflowId(decision.workflow_id),
        task_id=TaskId(decision.task_id),
        selected_model_group=selected,
        reason=decision.reason or "Governance allowed the routing request",
        rejected_candidates=rejected,
    )
