"""Run decisao-agent as an A2A server with governed routing and tracing."""

import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import uvicorn
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.routes import create_agent_card_routes, create_jsonrpc_routes
from a2a.server.tasks import InMemoryTaskStore
from a2a_otel_kit import Observability, ObservabilitySettings
from a2a_otel_kit.adapters.a2a import TracingRequestHandler
from starlette.applications import Starlette

from decisao_agent.adapters.credit_core_evaluation_adapter import CreditCoreEvaluationAdapter
from decisao_agent.adapters.governance_runtime_telemetry import (
    build_governance_runtime_telemetry,
)
from decisao_agent.adapters.litellm_client import LiteLLMClient
from decisao_agent.adapters.model_router_client import ModelRouterClient
from decisao_agent.adapters.policy_mcp_client import PolicyMcpClient
from decisao_agent.application.evaluate import EvaluateCreditApplicationUseCase
from decisao_agent.application.ports import RuntimeTelemetryPort
from decisao_agent.entrypoints.a2a_executor import DecisaoAgentExecutor
from decisao_agent.entrypoints.agent_card import build_agent_card

logger = logging.getLogger(__name__)

P1_5_GOVERNED_RUNTIME_TRACING = True

_HOST_ENV_VAR = "DECISAO_AGENT_A2A_HOST"
_PORT_ENV_VAR = "DECISAO_AGENT_A2A_PORT"
_POLICY_MCP_COMMAND_ENV_VAR = "DECISAO_AGENT_POLICY_MCP_COMMAND"
_DEFAULT_HOST = "127.0.0.1"
_DEFAULT_PORT = 9999


def build_app(
    base_url: str,
    *,
    runtime_telemetry: RuntimeTelemetryPort | None = None,
) -> Starlette:
    """Build the A2A app with tracing, governed routing, and optional runtime evidence."""
    environment = os.environ.get("DECISAO_AGENT_ENV", "local")
    observability = Observability.configure(
        ObservabilitySettings(
            service_name="decisao-agent",
            service_version="0.1.0",
            environment=environment,
        )
    )
    if runtime_telemetry is None:
        runtime_telemetry = build_governance_runtime_telemetry(environment)
    use_case = EvaluateCreditApplicationUseCase(
        evaluation_port=CreditCoreEvaluationAdapter(),
        policy_catalog_port=PolicyMcpClient(command=os.environ.get(_POLICY_MCP_COMMAND_ENV_VAR)),
        model_routing_port=ModelRouterClient(observability=observability),
        chat_completion_port=LiteLLMClient(),
    )
    agent_card = build_agent_card(base_url)
    request_handler = TracingRequestHandler.wrap(
        DefaultRequestHandler(
            agent_executor=DecisaoAgentExecutor(
                use_case,
                runtime_telemetry=runtime_telemetry,
            ),
            task_store=InMemoryTaskStore(),
            agent_card=agent_card,
        ),
        observability,
    )

    routes = list(create_agent_card_routes(agent_card))
    routes.extend(create_jsonrpc_routes(request_handler, "/"))

    @asynccontextmanager
    async def lifespan(_app: Starlette) -> AsyncIterator[None]:
        try:
            yield
        finally:
            observability.shutdown()

    return Starlette(routes=routes, lifespan=lifespan)


def main() -> None:
    """Run the A2A server, bound per DECISAO_AGENT_A2A_HOST/PORT."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    host = os.environ.get(_HOST_ENV_VAR, _DEFAULT_HOST)
    port = int(os.environ.get(_PORT_ENV_VAR, str(_DEFAULT_PORT)))
    app = build_app(f"http://{host}:{port}")

    logger.info("decisao_agent.a2a_server.starting", extra={"host": host, "port": port})
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
