import json
import logging
from collections.abc import Mapping

import pytest
from a2a_otel_kit.adapters.governance import (
    GovernanceRuntimeTelemetrySettings,
    GovernanceRuntimeTelemetrySink,
)
from a2a_otel_kit.domain.attributes import StructuredEvent
from opentelemetry.sdk.trace import TracerProvider

from decisao_agent.adapters.governance_runtime_telemetry import (
    GovernanceRuntimeTelemetryAdapter,
    build_governance_runtime_telemetry,
)

_AGENT_ID = "11111111-1111-4111-8111-111111111111"


class _RecordingSink:
    def __init__(self) -> None:
        self.events: list[StructuredEvent] = []

    async def emit(self, event: StructuredEvent) -> object:
        self.events.append(event)
        return object()


class _FailingSink:
    async def emit(self, event: StructuredEvent) -> object:
        raise RuntimeError("do-not-log-this-sensitive-message")


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


@pytest.mark.anyio
async def test_adapter_emits_only_structural_success_attributes() -> None:
    sink = _RecordingSink()
    adapter = GovernanceRuntimeTelemetryAdapter(sink)

    await adapter.evaluation_completed(
        correlation_id="workflow-1",
        request_id="task-1",
        duration_ms=12.5,
    )

    assert len(sink.events) == 1
    event = sink.events[0]
    assert event.event_name == "decisao_agent.evaluation.completed"
    assert event.event_outcome.value == "success"
    assert event.attributes == {
        "component": "a2a_executor",
        "operation": "credit_evaluation",
        "correlation_id": "workflow-1",
        "request_id": "task-1",
        "duration_ms": 12.5,
    }


@pytest.mark.anyio
async def test_adapter_failure_is_fail_open_and_does_not_log_exception_text(
    caplog: pytest.LogCaptureFixture,
) -> None:
    adapter = GovernanceRuntimeTelemetryAdapter(_FailingSink())

    with caplog.at_level(logging.WARNING):
        await adapter.evaluation_failed(
            correlation_id="workflow-1",
            request_id="task-1",
            duration_ms=4.0,
            error_type="ValidationError",
        )

    assert "runtime_telemetry_delivery_failed" in caplog.text
    record = caplog.records[-1]
    assert record.getMessage() == "decisao_agent.runtime_telemetry_delivery_failed"
    assert record.__dict__["error_type"] == "RuntimeError"
    assert "do-not-log-this-sensitive-message" not in caplog.text
    assert "do-not-log-this-sensitive-message" not in record.getMessage()


def test_governance_telemetry_is_disabled_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("DECISAO_AGENT_GOVERNANCE_TELEMETRY_ENABLED", raising=False)

    assert build_governance_runtime_telemetry("test") is None


def test_enabled_governance_telemetry_reuses_governed_agent_binding(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("DECISAO_AGENT_GOVERNANCE_TELEMETRY_ENABLED", "true")
    monkeypatch.setenv("DECISAO_AGENT_GOVERNANCE_BASE_URL", "http://127.0.0.1:8000")
    monkeypatch.setenv("DECISAO_AGENT_GOVERNANCE_AGENT_ID", _AGENT_ID)
    monkeypatch.delenv("DECISAO_AGENT_GOVERNANCE_TELEMETRY_API_KEY", raising=False)

    adapter = build_governance_runtime_telemetry("test")

    assert isinstance(adapter, GovernanceRuntimeTelemetryAdapter)
    assert "TELEMETRY_API_KEY" not in repr(adapter)


@pytest.mark.anyio
async def test_a2a_otel_sink_preserves_active_trace_ids_and_never_serializes_content() -> None:
    payloads: list[dict[str, object]] = []

    def transport(
        endpoint: str,
        body: bytes,
        headers: Mapping[str, str],
        timeout_seconds: float,
    ) -> int:
        payloads.append(json.loads(body))
        assert endpoint.endswith(f"/api/v1/agents/{_AGENT_ID}/runtime-telemetry")
        assert headers["X-Telemetry-Api-Key"] == "test-only-credential"
        assert timeout_seconds == 2.0
        return 202

    sink = GovernanceRuntimeTelemetrySink(
        settings=GovernanceRuntimeTelemetrySettings(
            base_url="http://127.0.0.1:8000",
            agent_id=_AGENT_ID,
            service="decisao-agent",
            environment="test",
            version="0.1.0",
            max_attempts=1,
        ),
        credential_provider=lambda: "test-only-credential",
        transport=transport,
    )
    adapter = GovernanceRuntimeTelemetryAdapter(sink)

    provider = TracerProvider()
    tracer = provider.get_tracer(__name__)
    try:
        with tracer.start_as_current_span("test-credit-evaluation"):
            await adapter.evaluation_completed(
                correlation_id="workflow-1",
                request_id="task-1",
                duration_ms=1.25,
            )
    finally:
        provider.shutdown()

    assert len(payloads) == 1
    payload = payloads[0]
    assert isinstance(payload["trace_id"], str)
    assert len(payload["trace_id"]) == 32
    assert isinstance(payload["span_id"], str)
    assert len(payload["span_id"]) == 16
    assert payload["correlation_id"] == "workflow-1"
    assert payload["request_id"] == "task-1"
    serialized = json.dumps(payload)
    for forbidden in (
        "prompt",
        "narrative",
        "annual_revenue",
        "credit_opinion",
        "test-only-credential",
    ):
        assert forbidden not in serialized
