"""Domain-specific exceptions raised by decisao-agent's evaluation use case."""


class DecisaoAgentError(Exception):
    """Base exception for every decisao-agent domain error."""


class InvalidApplicationSnapshotError(DecisaoAgentError):
    """Raised when an ``ApplicationSnapshot`` violates an input invariant.

    Translates ``credit_core.errors.InvalidCreditApplicationError`` at the adapter boundary, per
    ``.claude/rules/architecture.md``'s "translate infrastructure exceptions at adapter
    boundaries" - no other layer ever needs to know a ``credit_core`` exception type exists.
    """

    def __init__(self, reason: str) -> None:
        """Initialize the error with the violated snapshot invariant."""
        self.reason = reason
        super().__init__(f"Invalid application snapshot: {reason}")


class UnknownCriticalFlagError(DecisaoAgentError):
    """Raised when a snapshot names a critical flag policy-mcp does not recognize."""

    def __init__(self, flag_names: frozenset[str]) -> None:
        """Initialize the error with the unknown critical flags."""
        self.flag_names = flag_names
        super().__init__(f"Unknown critical flag(s): {sorted(flag_names)!r}.")


class PolicyCatalogUnavailableError(DecisaoAgentError):
    """Raised when policy-mcp's catalog cannot be reached or returns an unexpected error."""

    def __init__(self, reason: str) -> None:
        """Initialize the error with the catalog failure reason."""
        self.reason = reason
        super().__init__(f"policy-mcp catalog unavailable: {reason}")


class ModelRoutingUnavailableError(DecisaoAgentError):
    """Raised when a governed model-routing decision cannot be obtained."""

    def __init__(self, reason: str) -> None:
        """Initialize the error with the governed-routing failure reason."""
        self.reason = reason
        super().__init__(f"governed model routing unavailable: {reason}")


class ModelRoutingDeniedError(ModelRoutingUnavailableError):
    """Raised when Governance durably blocks a model-routing attempt."""

    def __init__(
        self,
        *,
        routing_decision_id: str,
        reason_code: str,
    ) -> None:
        """Initialize a durable Governance routing denial."""
        self.routing_decision_id = routing_decision_id
        self.reason_code = reason_code
        super().__init__("Governance blocked the model-routing request")


class ChatCompletionUnavailableError(DecisaoAgentError):
    """Raised when LiteLLM cannot be reached or returns an unexpected response."""

    def __init__(self, reason: str) -> None:
        """Initialize the error with the completion failure reason."""
        self.reason = reason
        super().__init__(f"chat completion unavailable: {reason}")


class PolicyVersionMismatchError(DecisaoAgentError):
    """Raised when credit_core applies a policy version policy-mcp does not know about."""

    def __init__(self, version: str) -> None:
        """Initialize the error with the inconsistent policy version."""
        self.version = version
        super().__init__(
            f"credit_core applied policy version {version!r}, which policy-mcp does not know."
        )
