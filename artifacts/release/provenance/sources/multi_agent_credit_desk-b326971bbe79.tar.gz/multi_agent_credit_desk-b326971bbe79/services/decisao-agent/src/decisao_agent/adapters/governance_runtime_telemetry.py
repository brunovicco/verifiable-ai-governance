"""Privacy-safe Governance runtime telemetry adoption for decisao-agent."""

from __future__ import annotations

import logging
import os
from typing import Protocol

from a2a_otel_kit.adapters.governance import (
    GovernanceRuntimeTelemetrySettings,
    GovernanceRuntimeTelemetrySink,
)
from a2a_otel_kit.domain.attributes import StructuredEvent, StructuredEventOutcome

from decisao_agent.application.ports import RuntimeTelemetryPort

logger = logging.getLogger(__name__)

_ENABLED_ENV = "DECISAO_AGENT_GOVERNANCE_TELEMETRY_ENABLED"
_API_KEY_ENV = "DECISAO_AGENT_GOVERNANCE_TELEMETRY_API_KEY"
_BASE_URL_ENV = "DECISAO_AGENT_GOVERNANCE_BASE_URL"
_AGENT_ID_ENV = "DECISAO_AGENT_GOVERNANCE_AGENT_ID"

_SERVICE_NAME = "decisao-agent"
_SERVICE_VERSION = "0.1.0"
_COMPONENT = "a2a_executor"
_OPERATION = "credit_evaluation"


class _RuntimeTelemetrySink(Protocol):
    """Minimal sink surface required by the Credit Desk adapter."""

    async def emit(self, event: StructuredEvent) -> object:
        """Deliver one already-sanitized structured event."""
        ...


class GovernanceRuntimeTelemetryAdapter(RuntimeTelemetryPort):
    """Emit Credit Desk lifecycle telemetry through the a2a-otel-kit Governance sink.

    Delivery is deliberately fail-open for the deterministic business workflow. A telemetry
    failure is logged by exception type only and is never recursively re-emitted as telemetry.
    """

    def __init__(self, sink: _RuntimeTelemetrySink) -> None:
        """Initialize the adapter with an explicit outbound telemetry sink."""
        self._sink = sink

    async def evaluation_completed(
        self,
        *,
        correlation_id: str,
        request_id: str,
        duration_ms: float,
    ) -> None:
        """Emit one successful terminal credit-evaluation event."""
        await self._emit(
            StructuredEvent(
                event_name="decisao_agent.evaluation.completed",
                event_outcome=StructuredEventOutcome.SUCCESS,
                attributes={
                    "component": _COMPONENT,
                    "operation": _OPERATION,
                    "correlation_id": correlation_id,
                    "request_id": request_id,
                    "duration_ms": duration_ms,
                },
            )
        )

    async def evaluation_failed(
        self,
        *,
        correlation_id: str,
        request_id: str,
        duration_ms: float,
        error_type: str,
    ) -> None:
        """Emit one failed terminal credit-evaluation event."""
        await self._emit(
            StructuredEvent(
                event_name="decisao_agent.evaluation.failed",
                event_outcome=StructuredEventOutcome.FAILURE,
                attributes={
                    "component": _COMPONENT,
                    "operation": _OPERATION,
                    "correlation_id": correlation_id,
                    "request_id": request_id,
                    "duration_ms": duration_ms,
                    "error.type": error_type,
                },
            )
        )

    async def _emit(self, event: StructuredEvent) -> None:
        """Deliver telemetry without allowing the optional sink to alter business behavior."""
        try:
            await self._sink.emit(event)
        except Exception as exc:
            logger.warning(
                "decisao_agent.runtime_telemetry_delivery_failed",
                extra={"error_type": type(exc).__name__},
            )


def build_governance_runtime_telemetry(environment: str) -> RuntimeTelemetryPort | None:
    """Build the opt-in Governance telemetry adapter from process configuration.

    The API key is never copied into representable settings. It is resolved lazily by the
    credential provider on every delivery, which supports external rotation without rebuilding
    the application object.
    """
    if not _telemetry_enabled():
        return None

    base_url = _required_env(_BASE_URL_ENV)
    agent_id = _required_env(_AGENT_ID_ENV)

    sink = GovernanceRuntimeTelemetrySink(
        settings=GovernanceRuntimeTelemetrySettings(
            base_url=base_url,
            agent_id=agent_id,
            service=_SERVICE_NAME,
            environment=environment,
            version=_SERVICE_VERSION,
        ),
        credential_provider=_runtime_telemetry_api_key,
    )
    return GovernanceRuntimeTelemetryAdapter(sink)


def _telemetry_enabled() -> bool:
    """Parse the explicit opt-in flag without accepting ambiguous values."""
    raw = os.environ.get(_ENABLED_ENV, "false").strip().lower()
    if raw in {"false", "0", "no", "off"}:
        return False
    if raw in {"true", "1", "yes", "on"}:
        return True
    raise ValueError(f"{_ENABLED_ENV} must be a boolean value")


def _runtime_telemetry_api_key() -> str:
    """Resolve the current machine credential without retaining it in settings."""
    return _required_env(_API_KEY_ENV)


def _required_env(name: str) -> str:
    """Return one required environment value or fail with a content-free error."""
    value = os.environ.get(name, "").strip()
    if not value:
        raise ValueError(f"{name} must be configured when Governance telemetry is enabled")
    return value
