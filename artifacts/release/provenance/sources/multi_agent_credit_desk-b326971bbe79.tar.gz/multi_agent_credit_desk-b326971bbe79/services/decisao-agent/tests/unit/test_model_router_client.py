"""Behavior tests for the Governance-mediated ModelRouterClient."""

from datetime import UTC, datetime
from decimal import Decimal

import httpx
import pytest
from a2a_otel_kit import Observability, ObservabilitySettings
from opentelemetry.sdk.trace import TracerProvider

from credit_desk_contracts.enums import (
    DataClassification,
    ModelGroup,
    RiskLevel,
    Workload,
)
from credit_desk_contracts.identifiers import TaskId, WorkflowId
from credit_desk_contracts.routing import ModelRouteRequest
from decisao_agent.adapters.model_router_client import ModelRouterClient
from decisao_agent.domain.errors import (
    ModelRoutingDeniedError,
    ModelRoutingUnavailableError,
)

pytestmark = pytest.mark.anyio


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


def _request() -> ModelRouteRequest:
    return ModelRouteRequest(
        schema_version="1.0",
        requested_at=datetime.now(UTC),
        workflow_id=WorkflowId("wf-1"),
        task_id=TaskId("task-1"),
        agent_name="decisao-agent",
        workload=Workload.OPINION_DRAFTING,
        risk_level=RiskLevel.MEDIUM,
        data_classification=DataClassification.INTERNAL,
        context_tokens_estimated=2000,
        max_output_tokens_estimated=900,
        structured_output_required=False,
        max_latency_ms=30000,
        max_cost_usd=Decimal("0.50"),
    )


def _decision_body(
    *,
    outcome: str = "allowed",
    selected_model_group: str | None = "reasoning-strong",
    reason_code: str | None = None,
) -> dict[str, object]:
    now = datetime.now(UTC).isoformat()
    return {
        "id": "decision-1",
        "ai_system_id": "system-1",
        "initiative_id": "initiative-1",
        "agent_id": "agent-1",
        "requested_by": "demo.requester",
        "requested_at": now,
        "scope_digest": "a" * 64,
        "workflow_id": "wf-1",
        "task_id": "task-1",
        "workload": "opinion_drafting",
        "risk_level": "medium",
        "data_classification": "internal",
        "context_tokens_estimated": 2000,
        "max_output_tokens_estimated": 900,
        "structured_output_required": False,
        "max_latency_ms": 30000,
        "max_cost_usd": "0.50",
        "outcome": outcome,
        "decision_source": "policy_model_router",
        "router_decision_id": "router-1",
        "router_outcome": "accepted",
        "decided_at": now,
        "selected_model_group": selected_model_group,
        "rejected_model_group": None,
        "reason": "governed decision",
        "reason_code": reason_code,
        "observed_value": None,
        "required_value": None,
        "rejected_candidates": [],
        "policy_id": "credit-desk-routing",
        "policy_version": "1.0.0",
        "policy_digest": "b" * 64,
        "service_version": "0.3.0",
        "environment": "test",
        "runtime_violation": None,
        "version": 1,
        "created_at": now,
        "updated_at": now,
    }


async def test_route_calls_governance_and_returns_allowed_model_group() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == ("/api/v1/agents/agent-1/routing-decisions")
        assert request.headers["x-user-id"] == "demo.requester"
        assert request.headers.get("x-api-key") is None
        payload = request.read().decode()
        assert "authorization" not in payload
        return httpx.Response(200, json=_decision_body())

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        transport=httpx.MockTransport(handler),
    )

    decision = await client.route(_request())

    assert decision.routing_decision_id == "decision-1"
    assert decision.selected_model_group == ModelGroup.REASONING_STRONG


async def test_route_propagates_w3c_trace_context_to_governance() -> None:
    provider = TracerProvider()
    observability = Observability(
        settings=ObservabilitySettings(
            service_name="decisao-agent-test",
            service_version="0.1.0",
            environment="test",
            enabled=False,
        ),
        tracer=provider.get_tracer("decisao-agent-test"),
        lifecycle=None,
    )

    async def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["traceparent"].startswith("00-")
        return httpx.Response(200, json=_decision_body())

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        observability=observability,
        transport=httpx.MockTransport(handler),
    )

    await client.route(_request())
    provider.shutdown()


async def test_route_surfaces_governance_block_as_denial() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            json=_decision_body(
                outcome="blocked",
                selected_model_group=None,
                reason_code="selected_model_group_not_approved",
            ),
        )

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ModelRoutingDeniedError) as raised:
        await client.route(_request())

    assert raised.value.routing_decision_id == "decision-1"
    assert raised.value.reason_code == "selected_model_group_not_approved"


async def test_route_fails_closed_without_governance_authentication() -> None:
    client = ModelRouterClient(
        agent_id="agent-1",
        transport=httpx.MockTransport(lambda request: httpx.Response(500, request=request)),
    )

    with pytest.raises(ModelRoutingUnavailableError):
        await client.route(_request())


async def test_route_rejects_mismatched_governance_decision() -> None:
    body = _decision_body()
    body["task_id"] = "other-task"

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=body)

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ModelRoutingUnavailableError):
        await client.route(_request())


async def test_route_rejects_malformed_response_body() -> None:
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"unexpected": "shape"})

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ModelRoutingUnavailableError):
        await client.route(_request())


@pytest.mark.parametrize(
    "reason_code",
    ["kill_switch_engaged", "runtime_authorization_revoked"],
)
async def test_route_preserves_runtime_control_denial_reason(reason_code: str) -> None:
    body = _decision_body(
        outcome="blocked",
        selected_model_group=None,
        reason_code=reason_code,
    )
    body["decision_source"] = "policy_model_router"
    body["router_decision_id"] = None
    body["router_outcome"] = None
    body["runtime_violation"] = {
        "schema_version": "1.0",
        "event": {"code": reason_code},
        "event_digest": "c" * 64,
    }

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(422, json=body)

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ModelRoutingDeniedError) as raised:
        await client.route(_request())

    assert raised.value.routing_decision_id == "decision-1"
    assert raised.value.reason_code == reason_code


async def test_route_maps_untrusted_runtime_control_to_dependency_unavailable() -> None:
    body = _decision_body(
        outcome="dependency_unavailable",
        selected_model_group=None,
        reason_code="runtime_control_unavailable",
    )
    body["decision_source"] = "governance_registry"
    body["router_decision_id"] = None
    body["router_outcome"] = None

    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, json=body)

    client = ModelRouterClient(
        agent_id="agent-1",
        dev_user_id="demo.requester",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ModelRoutingUnavailableError) as raised:
        await client.route(_request())

    assert raised.value.reason == "Governance routing dependency is unavailable"
