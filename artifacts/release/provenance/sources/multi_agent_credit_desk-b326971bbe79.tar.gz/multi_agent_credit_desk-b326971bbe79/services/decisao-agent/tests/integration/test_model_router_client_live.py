"""Live check for decisao-agent -> Governance -> policy-model-router.

The test is intentionally excluded from the default gate by the ``integration``
marker. Run it only when a Governance API is available with P1.3/P1.4/P1.5
enabled and the canonical demo agent has been seeded.
"""

import os
from datetime import UTC, datetime
from decimal import Decimal

import pytest

from credit_desk_contracts.enums import (
    DataClassification,
    ModelGroup,
    RiskLevel,
    Workload,
)
from credit_desk_contracts.identifiers import TaskId, WorkflowId
from credit_desk_contracts.routing import ModelRouteRequest
from decisao_agent.adapters.model_router_client import ModelRouterClient

pytestmark = [pytest.mark.integration, pytest.mark.anyio]

_AGENT_ID = os.environ.get("DECISAO_AGENT_GOVERNANCE_AGENT_ID")
_DEV_USER = os.environ.get("DECISAO_AGENT_GOVERNANCE_DEV_USER_ID")
_BEARER = os.environ.get("DECISAO_AGENT_GOVERNANCE_BEARER_TOKEN")


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


def _request() -> ModelRouteRequest:
    return ModelRouteRequest(
        schema_version="1.0",
        requested_at=datetime.now(UTC),
        workflow_id=WorkflowId("wf-governed-integration-test"),
        task_id=TaskId("task-opinion-drafting"),
        agent_name="decisao-agent",
        workload=Workload.OPINION_DRAFTING,
        risk_level=RiskLevel.HIGH,
        data_classification=DataClassification.RESTRICTED,
        context_tokens_estimated=2000,
        max_output_tokens_estimated=900,
        structured_output_required=False,
        max_latency_ms=30000,
        max_cost_usd=Decimal("0.30"),
    )


@pytest.mark.skipif(
    not _AGENT_ID or (not _DEV_USER and not _BEARER),
    reason="Governance live-test identity is not configured",
)
async def test_governance_selects_reasoning_strong_for_opinion_drafting() -> None:
    client = ModelRouterClient()

    decision = await client.route(_request())

    assert decision.selected_model_group == ModelGroup.REASONING_STRONG
    assert str(decision.routing_decision_id)
