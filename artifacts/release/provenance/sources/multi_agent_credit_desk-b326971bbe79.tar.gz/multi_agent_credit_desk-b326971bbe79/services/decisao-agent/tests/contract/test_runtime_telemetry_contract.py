import json
from collections.abc import AsyncIterator

import httpx
import pytest
from a2a.client import Client, ClientConfig, create_client
from a2a.helpers.proto_helpers import new_text_message
from a2a.types import Role, SendMessageRequest, Task, TaskState

from decisao_agent.application.ports import RuntimeTelemetryPort
from decisao_agent.entrypoints.a2a_server import build_app
from decisao_agent.entrypoints.agent_card import build_agent_card

pytestmark = [pytest.mark.contract, pytest.mark.anyio]

_BASE_URL = "http://testserver"
_HEALTHY_INPUT = json.dumps(
    {
        "annual_revenue": "1000000",
        "total_debt": "300000",
        "monthly_debt_service": "10000",
        "monthly_operating_cash_flow": "25000",
        "bureau_score": "850",
        "years_in_operation": 12,
        "requested_amount": "30000",
        "critical_flags": [],
    }
)


class _RecordingTelemetry(RuntimeTelemetryPort):
    def __init__(self) -> None:
        self.completed: list[tuple[str, str, float]] = []
        self.failed: list[tuple[str, str, float, str]] = []

    async def evaluation_completed(
        self,
        *,
        correlation_id: str,
        request_id: str,
        duration_ms: float,
    ) -> None:
        self.completed.append((correlation_id, request_id, duration_ms))

    async def evaluation_failed(
        self,
        *,
        correlation_id: str,
        request_id: str,
        duration_ms: float,
        error_type: str,
    ) -> None:
        self.failed.append((correlation_id, request_id, duration_ms, error_type))


@pytest.fixture
def anyio_backend() -> str:
    return "asyncio"


async def _client(telemetry: RuntimeTelemetryPort) -> AsyncIterator[Client]:
    agent_card = build_agent_card(_BASE_URL)
    app = build_app(_BASE_URL, runtime_telemetry=telemetry)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url=_BASE_URL,
    ) as httpx_client:
        client = await create_client(
            agent_card,
            client_config=ClientConfig(streaming=False, httpx_client=httpx_client),
        )
        try:
            yield client
        finally:
            await client.close()


async def _send_and_get_task(client: Client, text: str) -> Task:
    request = SendMessageRequest(
        message=new_text_message(text, media_type="application/json", role=Role.ROLE_USER)
    )
    task: Task | None = None
    async for response in client.send_message(request):
        task = response.task
    assert task is not None
    return task


async def test_completed_task_emits_structural_runtime_telemetry() -> None:
    telemetry = _RecordingTelemetry()
    async for client in _client(telemetry):
        task = await _send_and_get_task(client, _HEALTHY_INPUT)

    assert task.status.state == TaskState.TASK_STATE_COMPLETED
    assert len(telemetry.completed) == 1
    correlation_id, request_id, duration_ms = telemetry.completed[0]
    assert correlation_id == task.context_id
    assert request_id == task.id
    assert duration_ms >= 0
    assert telemetry.failed == []


async def test_failed_task_emits_error_type_without_request_content() -> None:
    telemetry = _RecordingTelemetry()
    async for client in _client(telemetry):
        task = await _send_and_get_task(client, "not valid json")

    assert task.status.state == TaskState.TASK_STATE_FAILED
    assert len(telemetry.failed) == 1
    correlation_id, request_id, duration_ms, error_type = telemetry.failed[0]
    assert correlation_id == task.context_id
    assert request_id == task.id
    assert duration_ms >= 0
    assert error_type == "ValidationError"
    assert telemetry.completed == []
