"""Infrastructure adapter implementations."""
