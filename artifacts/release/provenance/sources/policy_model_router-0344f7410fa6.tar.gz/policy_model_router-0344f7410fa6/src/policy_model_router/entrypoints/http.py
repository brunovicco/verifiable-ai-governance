"""HTTP entrypoint: ``POST /route``, plus ``/health``, ``/readyz``, and ``/metrics``.

The model-routing decision endpoint agents call over HTTP before every LLM call. Per ADR-0004,
this service is infrastructure, not an A2A agent: agents call it directly, it is not discovered
through Agent Cards or the A2A protocol. Per ADR-0007 (amended) and ADR-0008's second amendment,
``/route`` requires a per-agent API key and is rate-limited on two tiers - a light per-client-IP
tier, then a per-(IP, agent) tier - before authentication, so repeated invalid-API-key attempts
are throttled too, and an attacker cannot bypass the per-agent tier merely by varying the claimed
``agent_name``. ``/health``, ``/readyz``, and ``/metrics`` are unauthenticated and unthrottled so
orchestrators and scrapers can probe them cheaply. Every request is bound to a correlation ID
(``X-Correlation-Id``, reused from the caller or generated) for the duration of its handling, so
every log line emitted while processing it - including from adapters like the Redis rate limiter -
carries the same ID; see ``entrypoints/logging.py``.
"""

import asyncio
import json
import os
import secrets
import time
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from importlib.metadata import PackageNotFoundError, version
from typing import Annotated, Protocol

import structlog
from a2a_otel_kit import Observability, ObservabilitySettings, continue_trace
from fastapi import Depends, FastAPI, Header, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from opentelemetry.trace import SpanKind
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from starlette.types import ASGIApp, Receive, Scope, Send

from policy_model_router.adapters.availability import StaticAvailabilityProvider
from policy_model_router.adapters.clock import SystemClock
from policy_model_router.adapters.id_generator import Uuid4IdGenerator
from policy_model_router.adapters.rate_limiter import InMemoryRateLimiter, RateLimitExceededError
from policy_model_router.adapters.redis_rate_limiter import RedisRateLimiter
from policy_model_router.adapters.routing_policy_loader import load_routing_policy
from policy_model_router.application.route_model import (
    IncompleteRoutingPolicyError,
    RouteModelUseCase,
)
from policy_model_router.domain.routing import NoViableModelGroupError
from policy_model_router.entrypoints.contracts import (
    AuthorizedModelRouteRequest,
    ModelRouteDecision,
    RouteRequestEnvelope,
    from_domain_decision,
    from_domain_rejection,
    to_domain_request,
)
from policy_model_router.entrypoints.logging import (
    bind_correlation_id,
    clear_request_context,
)
from policy_model_router.entrypoints.runtime_authorization_factory import (
    build_runtime_authorization_verifier,
)
from policy_model_router.entrypoints.runtime_authorization_settings import (
    RuntimeAuthorizationSettings,
)
from policy_model_router.entrypoints.runtime_control_settings import RuntimeControlSettings
from policy_model_router.entrypoints.settings import Settings
from policy_model_router.runtime_authorization import (
    RuntimeAuthorizationError,
    RuntimeAuthorizationVerifier,
)
from policy_model_router.runtime_violation import build_runtime_violation

_SERVICE_NAME = "policy-model-router"
P1_3_RUNTIME_AUTHORIZATION_ENFORCEMENT = True
P1_4_RUNTIME_VIOLATION_EVENTS = True
P1_5_DISTRIBUTED_RUNTIME_TRACING = True
P1_6_RUNTIME_KILL_SWITCH_ENFORCEMENT = True
_MAX_CORRELATION_ID_LENGTH = 200

ROUTE_DECISIONS_TOTAL = Counter(
    "policy_model_router_route_decisions_total",
    "Successful routing decisions, labeled by workload and the selected model group.",
    ["workload", "model_group"],
)
ROUTE_REJECTIONS_TOTAL = Counter(
    "policy_model_router_route_rejections_total",
    "Routing requests that did not produce a decision, labeled by workload and outcome.",
    ["workload", "outcome"],
)
ROUTE_DURATION_SECONDS = Histogram(
    "policy_model_router_route_duration_seconds",
    "Time spent evaluating one routing decision (RouteModelUseCase.route only), by workload.",
    ["workload"],
)
RATE_LIMIT_DECISIONS_TOTAL = Counter(
    "policy_model_router_rate_limit_decisions_total",
    "Rate limiter admit/block decisions, labeled by tier (per_ip, per_agent) and outcome.",
    ["tier", "outcome"],
)
RUNTIME_AUTHORIZATION_TOTAL = Counter(
    "policy_model_router_runtime_authorization_total",
    "Runtime authorization checks labeled by bounded outcome.",
    ["outcome"],
)
RUNTIME_VIOLATIONS_TOTAL = Counter(
    "policy_model_router_runtime_violations_total",
    "Fail-closed runtime violations labeled by bounded category and reason code.",
    ["category", "code"],
)

logger = structlog.get_logger(__name__)


class RateLimiter(Protocol):
    """Port for admitting or rejecting one more request for a given key.

    Defined here, not in ``application/ports.py``: this protects the HTTP boundary only - the
    application use case never rate-limits anything - so the consumer-side port lives next to its
    only consumer, this module. Two implementations exist: ``InMemoryRateLimiter`` (default,
    per-process) and the optional, Redis-backed ``RedisRateLimiter`` shared across replicas
    (ADR-0008).
    """

    async def allow(self, key: str) -> bool:
        """Return whether one more request for ``key`` is within its current limit."""
        ...

    async def ping(self) -> None:
        """Verify the limiter's backend is reachable; raise if it is not.

        Called once at startup so a misconfigured backend fails the service closed immediately,
        rather than surfacing as a per-request failure later.
        """
        ...

    async def close(self) -> None:
        """Release any backend connection held by this limiter.

        Called once during graceful shutdown, after the lifespan's ``yield``, so a Redis-backed
        limiter's connection is not simply dropped when the process exits.
        """
        ...


class _BodySizeAndIpRateLimitMiddleware:
    """Enforce the body-size cap and the per-IP rate-limit tier before FastAPI parses the body.

    A pure ASGI middleware, not the ``@app.middleware("http")``/``BaseHTTPMiddleware`` style used
    by ``_bind_correlation_id`` below: that style already buffers the request body via
    ``call_next`` before this code would run, defeating a pre-parse check. This wraps the raw ASGI
    callable directly, so both checks run before any body bytes are read - closing the gap where a
    malformed or oversized ``/route`` body previously bypassed both rate-limit tiers entirely
    (ADR-0011).

    Registered via ``app.add_middleware`` *before* the ``_bind_correlation_id`` decorator runs, so
    it ends up wrapped by (inside) the correlation-ID binder: a short-circuited 413/429 response
    still gets ``X-Correlation-Id`` bound and echoed, same as every other response.

    Scope: the per-IP rate-limit check applies only to ``POST /route`` (``/health``/``/readyz``/
    ``/metrics`` stay unthrottled, matching ADR-0007's design). The body-size check is a
    ``Content-Length`` header comparison only - a deliberate scope decision, not an oversight: a
    chunked-transfer-encoding body with no ``Content-Length`` is an accepted residual gap for this
    service's documented deployment model (behind an authenticated gateway, per ADR-0004), not a
    full streaming byte-cap.
    """

    def __init__(self, app: ASGIApp) -> None:
        """Wrap ``app``. The body-size cap is read from ``app.state`` per request, not fixed here.

        Unlike the rate limiters (also built once in ``_lifespan``), the numeric cap itself is
        cheap to read fresh every request, so it is stored directly on ``app.state`` at startup
        (``app.state.max_request_body_bytes``) rather than baked into this middleware's
        constructor - which runs once at import time, before ``Settings()`` has been re-read for
        the process actually serving traffic (e.g. under a test harness that reconfigures the
        environment per test and re-triggers the lifespan, not the module import).
        """
        self._app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Run the per-IP rate limit and body-size checks, or pass through to the wrapped app."""
        if scope["type"] != "http":
            await self._app(scope, receive, send)
            return

        app_state = scope["app"].state

        if scope["path"] == "/route" and scope["method"] == "POST":
            client = scope.get("client")
            client_host = client[0] if client else "unknown"
            ip_allowed = await app_state.ip_rate_limiter.allow(f"ip:{client_host}")
            RATE_LIMIT_DECISIONS_TOTAL.labels(
                tier="per_ip", outcome="allowed" if ip_allowed else "blocked"
            ).inc()
            if not ip_allowed:
                response = _error_response(
                    429, "rate_limit_exceeded", "too many requests, try again later"
                )
                await response(scope, receive, send)
                return

        max_body_bytes = app_state.max_request_body_bytes
        content_length = next(
            (value for key, value in scope["headers"] if key == b"content-length"), None
        )
        if content_length is not None and int(content_length) > max_body_bytes:
            response = _error_response(
                413,
                "payload_too_large",
                f"request body exceeds the {max_body_bytes}-byte limit",
            )
            await response(scope, receive, send)
            return

        await self._app(scope, receive, send)


class AuthenticationError(Exception):
    """Raised when a request to a protected route has a missing or invalid API key."""


def _service_version() -> str:
    """Return the installed package version, or a placeholder outside a packaged install."""
    try:
        return version(_SERVICE_NAME)
    except PackageNotFoundError:
        return "0.0.0-dev"


def _required_api_keys() -> dict[str, str]:
    """Return the configured per-agent API keys, failing fast if they are missing or malformed.

    Deny-by-default: an unset, empty, or malformed ``API_KEYS`` stops the service from starting
    rather than serving ``/route`` unauthenticated. Per ADR-0007's amendment, this is a mapping of
    ``agent_name`` to that agent's own key, not one shared secret for every caller.
    """
    raw = os.environ.get("API_KEYS", "")
    if not raw:
        raise RuntimeError("API_KEYS environment variable is required to start this service")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "API_KEYS environment variable must be a JSON object mapping agent_name to API key"
        ) from exc
    if (
        not isinstance(parsed, dict)
        or not parsed
        or not all(isinstance(k, str) and k and isinstance(v, str) and v for k, v in parsed.items())
    ):
        raise RuntimeError(
            "API_KEYS environment variable must be a non-empty JSON object of "
            "non-empty string agent_name/key pairs"
        )
    return parsed


def _api_docs_enabled() -> bool:
    """Return whether OpenAPI docs (``/docs``, ``/redoc``, ``/openapi.json``) should be served.

    Disabled by default (deny by default, per ``.claude/rules/security-privacy.md``): a minor
    recon surface (route shapes, field names) that orchestrators/scrapers never need, unlike
    ``/health``/``/readyz``/``/metrics``. Set ``ENABLE_API_DOCS=true`` for local development.
    """
    return Settings().enable_api_docs


def _build_rate_limiter(
    *,
    max_requests: int,
    window_seconds: float,
    max_tracked_keys: int,
    redis_url: str | None,
    fingerprint_secret: bytes | None = None,
) -> RateLimiter:
    """Build the configured rate limiter.

    Redis-backed and shared across replicas if ``redis_url`` is set (ADR-0008); otherwise the
    default in-memory, per-process limiter. Raises ``RuntimeError`` (fail closed) if ``redis_url``
    is set but the optional ``redis`` package is not installed - a silent fallback to per-process
    behavior would defeat the reason the operator configured it.
    """
    if not redis_url:
        return InMemoryRateLimiter(
            max_requests=max_requests,
            window_seconds=window_seconds,
            max_tracked_keys=max_tracked_keys,
        )

    try:
        from redis.asyncio import Redis
    except ImportError as exc:
        raise RuntimeError(
            "REDIS_URL is set but the 'redis' package is not installed; "
            "install it with `uv sync --extra rate-limit`"
        ) from exc

    client = Redis.from_url(redis_url, socket_connect_timeout=2.0, socket_timeout=2.0)
    return RedisRateLimiter(
        client,
        max_requests=max_requests,
        window_seconds=window_seconds,
        fingerprint_secret=fingerprint_secret,
    )


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Configure logging and load the routing policy, API keys, and rate limiters at startup.

    Fails fast if the routing policy is missing/invalid, the API keys are not configured, or
    either rate limiter's backend (when Redis-backed) is not reachable. Closes both limiters'
    backend connections after the ``yield``, so a Redis-backed connection is released on graceful
    shutdown rather than simply dropped; both are attempted (via ``asyncio.gather(...,
    return_exceptions=True)``) even if one raises, so a failure releasing one tier's connection
    can never skip releasing the other's.
    """
    settings = Settings()
    service_version = _service_version()
    observability = Observability.configure(
        ObservabilitySettings(
            service_name=_SERVICE_NAME,
            service_version=service_version,
            environment=settings.app_env,
            log_level=settings.log_level,
            log_format=settings.log_format,
        )
    )
    app.state.observability = observability

    policy = load_routing_policy(settings.routing_policy_path)
    app.state.route_model_use_case = RouteModelUseCase(
        policy,
        clock=SystemClock(),
        id_generator=Uuid4IdGenerator(),
        availability=StaticAvailabilityProvider(),
        service_version=service_version,
        environment=settings.app_env,
    )
    app.state.api_keys = _required_api_keys()
    app.state.max_request_body_bytes = settings.max_request_body_bytes
    app.state.service_version = service_version
    app.state.environment = settings.app_env

    runtime_authorization_settings = RuntimeAuthorizationSettings()
    runtime_control_settings = RuntimeControlSettings()
    runtime_authorization_verifier = build_runtime_authorization_verifier(
        runtime_authorization_settings,
        app_env=settings.app_env,
        redis_url=settings.redis_url,
        runtime_control_settings=runtime_control_settings,
    )
    await runtime_authorization_verifier.ping()
    app.state.runtime_authorization_settings = runtime_authorization_settings
    app.state.runtime_control_settings = runtime_control_settings
    app.state.runtime_authorization_verifier = runtime_authorization_verifier

    fingerprint_secret = (
        settings.rate_limit_fingerprint_secret.encode()
        if settings.rate_limit_fingerprint_secret
        else None
    )
    rate_limiter = _build_rate_limiter(
        max_requests=settings.rate_limit_max_requests,
        window_seconds=settings.rate_limit_window_seconds,
        max_tracked_keys=settings.rate_limit_max_tracked_keys,
        redis_url=settings.redis_url,
        fingerprint_secret=fingerprint_secret,
    )
    ip_rate_limiter = _build_rate_limiter(
        max_requests=settings.rate_limit_per_ip_max_requests,
        window_seconds=settings.rate_limit_window_seconds,
        max_tracked_keys=settings.rate_limit_max_tracked_keys,
        redis_url=settings.redis_url,
        fingerprint_secret=fingerprint_secret,
    )
    try:
        await rate_limiter.ping()
        await ip_rate_limiter.ping()
    except Exception as exc:
        raise RuntimeError(f"rate limiter backend is not reachable: {exc}") from exc
    app.state.rate_limiter = rate_limiter
    app.state.ip_rate_limiter = ip_rate_limiter

    yield

    await asyncio.gather(
        rate_limiter.close(),
        ip_rate_limiter.close(),
        runtime_authorization_verifier.close(),
        return_exceptions=True,
    )
    observability.shutdown()


_docs_enabled = _api_docs_enabled()
app = FastAPI(
    title="policy-model-router",
    lifespan=_lifespan,
    docs_url="/docs" if _docs_enabled else None,
    redoc_url="/redoc" if _docs_enabled else None,
    openapi_url="/openapi.json" if _docs_enabled else None,
)

# Registered before the @app.middleware("http") decorator below, so it ends up wrapped by (inside)
# the correlation-ID binder - see _BodySizeAndIpRateLimitMiddleware's docstring for why the order
# matters.
app.add_middleware(_BodySizeAndIpRateLimitMiddleware)


@app.middleware("http")
async def _bind_correlation_id(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    """Bind a correlation ID to every log line emitted while handling this request.

    Reuses the caller's ``X-Correlation-Id`` header if present, so a caller's own logs and this
    service's logs can be joined on the same ID; generates one otherwise. An oversized header
    value (over ``_MAX_CORRELATION_ID_LENGTH``) is treated the same as a missing one - a fresh ID
    is generated instead - rather than rejecting the request outright: this header is a caller
    convenience, not a security control, so an oversized value only costs that one caller its own
    correlation, not a hard failure. Echoed back on the response so a caller that didn't send one
    can still correlate afterward. Always cleared once the request finishes, so it never leaks
    into a later, unrelated request's log lines.
    """
    raw_correlation_id = request.headers.get("X-Correlation-Id")
    correlation_id = (
        raw_correlation_id
        if raw_correlation_id and len(raw_correlation_id) <= _MAX_CORRELATION_ID_LENGTH
        else str(uuid.uuid4())
    )
    with (
        continue_trace(dict(request.headers)),
        request.app.state.observability.start_span(
            "policy_model_router.http.request",
            kind=SpanKind.SERVER,
            attributes={
                "component": "fastapi",
                "operation": "http.request",
                "correlation_id": correlation_id,
                "http.method": request.method,
            },
            record_exception=False,
        ) as span,
    ):
        bind_correlation_id(correlation_id)
        request.state.correlation_id = correlation_id
        try:
            response = await call_next(request)
            response.headers["X-Correlation-Id"] = correlation_id
            span.set_attribute("http.status_code", response.status_code)
            span.set_attribute(
                "outcome",
                "success" if response.status_code < 500 else "error",
            )
            return response
        except Exception as exc:
            span.set_attribute("outcome", "error")
            span.set_attribute("error.type", type(exc).__name__)
            raise
        finally:
            clear_request_context()


def get_route_model_use_case(request: Request) -> RouteModelUseCase:
    """Return the use case built at startup from the loaded routing policy."""
    use_case: RouteModelUseCase = request.app.state.route_model_use_case
    return use_case


def _authenticate(x_api_key: str | None, agent_name: str, api_keys: dict[str, str]) -> None:
    """Reject unless ``x_api_key`` matches the configured key for ``agent_name``.

    Looks the key up by claimed agent identity rather than accepting any configured key for any
    agent, so one agent's key can be rotated or revoked without affecting the others (ADR-0007's
    amendment). The error is identical whether the agent is unknown or the key is wrong, so the
    response never reveals which agent names are configured.
    """
    configured_key = api_keys.get(agent_name)
    if (
        configured_key is None
        or x_api_key is None
        or not secrets.compare_digest(x_api_key, configured_key)
    ):
        raise AuthenticationError(f"missing or invalid API key for agent {agent_name!r}")


def _error_response(status_code: int, code: str, message: str) -> JSONResponse:
    """Build the stable, machine-readable error envelope used by every handler below."""
    return JSONResponse(
        status_code=status_code, content={"error": {"code": code, "message": message}}
    )


@app.exception_handler(RequestValidationError)
async def _handle_validation_error(_request: Request, _exc: RequestValidationError) -> JSONResponse:
    """Map a malformed request body to a stable 422 envelope, without leaking schema internals."""
    return _error_response(
        422, "invalid_request", "the request body does not match the expected schema"
    )


@app.exception_handler(NoViableModelGroupError)
async def _handle_no_viable_model_group(
    _request: Request, exc: NoViableModelGroupError
) -> JSONResponse:
    """Map a hard routing failure to a 422 envelope, with the full rejected decision's provenance.

    ``error.code``/``error.message`` are unchanged from before this decision gained provenance;
    the ``decision`` key is purely additive, mirroring how ADR-0009 added provenance fields to the
    success response without breaking existing consumers.
    """
    rejection = from_domain_rejection(exc.decision)
    return JSONResponse(
        status_code=422,
        content={
            "error": {"code": "no_viable_model_group", "message": str(exc)},
            "decision": rejection.model_dump(mode="json"),
        },
    )


@app.exception_handler(IncompleteRoutingPolicyError)
async def _handle_incomplete_policy(
    _request: Request, _exc: IncompleteRoutingPolicyError
) -> JSONResponse:
    """Map a routing-policy configuration defect to a 500 envelope, without leaking internals."""
    return _error_response(
        500, "misconfigured_routing_policy", "the routing policy is misconfigured"
    )


@app.exception_handler(AuthenticationError)
async def _handle_authentication_error(
    _request: Request, _exc: AuthenticationError
) -> JSONResponse:
    """Map a missing or invalid API key to a stable 401 envelope."""
    return _error_response(401, "unauthorized", "missing or invalid API key")


@app.exception_handler(RateLimitExceededError)
async def _handle_rate_limit_exceeded(
    _request: Request, _exc: RateLimitExceededError
) -> JSONResponse:
    """Map an exceeded rate limit to a stable 429 envelope."""
    return _error_response(429, "rate_limit_exceeded", "too many requests, try again later")


@app.exception_handler(RuntimeAuthorizationError)
async def _handle_runtime_authorization_error(
    request: Request,
    exc: RuntimeAuthorizationError,
) -> JSONResponse:
    """Return digest-bound evidence with each runtime authorization denial."""
    RUNTIME_AUTHORIZATION_TOTAL.labels(outcome="denied").inc()
    route_request = getattr(request.state, "runtime_violation_route_request", None)
    if route_request is None:
        return _error_response(403, exc.code, "runtime authorization denied")

    violation = build_runtime_violation(
        code=exc.code,
        request=route_request,
        authorization=getattr(request.state, "runtime_violation_authorization", None),
        authorization_verified=(
            getattr(request.state, "runtime_violation_authorization_verified", False)
            or exc.authorization_verified
        ),
        correlation_id=getattr(request.state, "correlation_id", "unbound-request"),
        service_version=request.app.state.service_version,
        environment=request.app.state.environment,
        selected_model_group=getattr(request.state, "runtime_violation_selected_model_group", None),
    )
    event = violation.event
    RUNTIME_VIOLATIONS_TOTAL.labels(category=event.category.value, code=event.code).inc()
    logger.warning(
        "runtime_violation",
        violation_event_id=str(event.event_id),
        violation_category=event.category.value,
        reason_code=event.code,
        correlation_id=event.correlation_id,
        authorization_state=event.authorization.state.value,
        authorization_id=(
            str(event.authorization.authorization_id)
            if event.authorization.authorization_id is not None
            else None
        ),
        selected_model_group=event.selected_model_group,
        violation_digest=violation.event_digest,
    )
    return JSONResponse(
        status_code=403,
        content={
            "error": {
                "code": exc.code,
                "message": "runtime authorization denied",
            },
            "violation": violation.model_dump(mode="json"),
        },
    )


@app.get("/health")
async def health() -> dict[str, str]:
    """Liveness probe: always returns 200 once the process is serving requests."""
    return {"status": "ok"}


@app.get("/readyz")
async def readyz(request: Request) -> dict[str, str]:
    """Readiness probe: 200 once the routing policy loaded successfully at startup.

    This is a shallow check: when Redis is configured, startup probes it once, but this endpoint
    does not re-probe Redis or any future availability provider. Readiness here means "startup
    completed", not "every runtime dependency is currently healthy".
    """
    _ = request.app.state.route_model_use_case
    return {"status": "ready"}


@app.get("/metrics")
async def metrics() -> Response:
    """Expose Prometheus-format metrics, including the Redis rate limiter's failure counter.

    Includes ``policy_model_router_rate_limiter_backend_unavailable_total`` (ADR-0008's
    amendment): alert on a sustained increase, which means the Redis-backed rate limiter is
    failing open and the configured limit is not being enforced.
    """
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/route", response_model=ModelRouteDecision)
async def route(
    request: RouteRequestEnvelope,
    http_request: Request,
    use_case: Annotated[RouteModelUseCase, Depends(get_route_model_use_case)],
    x_api_key: Annotated[str | None, Header(alias="X-API-Key")] = None,
) -> ModelRouteDecision:
    """Evaluate one request only inside its signed Governance runtime scope."""
    route_request = request.request if isinstance(request, AuthorizedModelRouteRequest) else request
    authorization = (
        request.authorization if isinstance(request, AuthorizedModelRouteRequest) else None
    )
    http_request.state.runtime_violation_route_request = route_request
    http_request.state.runtime_violation_authorization = authorization
    http_request.state.runtime_violation_authorization_verified = False
    http_request.state.runtime_violation_selected_model_group = None
    client_host = http_request.client.host if http_request.client else "unknown"

    rate_limit_key = f"{client_host}:{route_request.agent_name}"
    agent_allowed = await http_request.app.state.rate_limiter.allow(rate_limit_key)
    RATE_LIMIT_DECISIONS_TOTAL.labels(
        tier="per_agent", outcome="allowed" if agent_allowed else "blocked"
    ).inc()
    if not agent_allowed:
        raise RateLimitExceededError(f"rate limit exceeded for {rate_limit_key!r}")

    _authenticate(
        x_api_key,
        route_request.agent_name,
        http_request.app.state.api_keys,
    )

    runtime_settings = http_request.app.state.runtime_authorization_settings
    verified_authorization = None
    if runtime_settings.required:
        if authorization is None:
            raise RuntimeAuthorizationError(
                "runtime_authorization_required",
                "Signed Governance runtime authorization is required",
            )
        verifier = http_request.app.state.runtime_authorization_verifier
        if not isinstance(verifier, RuntimeAuthorizationVerifier):
            raise RuntimeAuthorizationError(
                "runtime_authorization_unavailable",
                "Runtime authorization verifier is unavailable",
            )
        verified_authorization = await verifier.verify(
            authorization,
            route_request,
            now=SystemClock().now(),
        )
        http_request.state.runtime_violation_authorization_verified = True
        RUNTIME_AUTHORIZATION_TOTAL.labels(outcome="verified").inc()
    elif authorization is not None:
        raise RuntimeAuthorizationError(
            "runtime_authorization_not_configured",
            "Runtime authorization is disabled for this deployment",
        )
    else:
        RUNTIME_AUTHORIZATION_TOTAL.labels(outcome="legacy_dev").inc()

    workload = route_request.workload.value
    started_at = time.monotonic()
    try:
        decision = await use_case.route(to_domain_request(route_request))
    except NoViableModelGroupError as exc:
        ROUTE_REJECTIONS_TOTAL.labels(workload=workload, outcome="no_viable_model_group").inc()
        logger.info(
            "routing_decision",
            outcome="rejected",
            routing_decision_id=exc.decision.routing_decision_id,
            workload=workload,
            model_group=exc.decision.rejected_model_group.value,
            reason_code=exc.decision.reason_code.value,
            policy_id=exc.decision.policy_id,
            policy_version=exc.decision.policy_version,
            policy_digest=exc.decision.policy_digest,
            duration_ms=round((time.monotonic() - started_at) * 1000, 3),
        )
        raise
    except IncompleteRoutingPolicyError:
        ROUTE_REJECTIONS_TOTAL.labels(workload=workload, outcome="misconfigured_policy").inc()
        raise
    finally:
        ROUTE_DURATION_SECONDS.labels(workload=workload).observe(time.monotonic() - started_at)

    if verified_authorization is not None:
        http_request.state.runtime_violation_selected_model_group = (
            decision.selected_model_group.value
        )
        verifier.require_selected_model(
            verified_authorization,
            decision.selected_model_group,
        )

    ROUTE_DECISIONS_TOTAL.labels(
        workload=workload, model_group=decision.selected_model_group.value
    ).inc()
    logger.info(
        "routing_decision",
        outcome="accepted",
        routing_decision_id=decision.routing_decision_id,
        workload=workload,
        model_group=decision.selected_model_group.value,
        policy_id=decision.policy_id,
        policy_version=decision.policy_version,
        policy_digest=decision.policy_digest,
        duration_ms=round((time.monotonic() - started_at) * 1000, 3),
    )
    return from_domain_decision(decision)
